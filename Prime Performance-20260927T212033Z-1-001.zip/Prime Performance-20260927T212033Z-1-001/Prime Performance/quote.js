// =============================================
// PRIME PERFORMANCE — QUOTE REQUEST FORM
// =============================================
// Validates the form, shrinks photos in the browser and sends everything to POST /api/quote.
// The server repeats every check (netlify/functions/api.mjs); this file only makes errors visible sooner.

(() => {
    const form = document.getElementById('quote-form');
    if (!form) return;

    const MAX_PHOTOS = 5;
    const MAX_PHOTO_BYTES = 2 * 1024 * 1024;
    const PHOTO_MAX_SIDE = 1600;
    const SERVICES = ['remodelacao', 'construcao', 'pintura', 'eletricidade', 'canalizacao', 'reparacoes-bricolagem', 'outro'];
    const startedAt = Date.now();

    const submitButton = document.getElementById('q-submit');
    const submitLabel = document.getElementById('q-submit-label');
    const formError = document.getElementById('q-form-error');
    const photoInput = document.getElementById('q-photos');
    const photoList = document.getElementById('q-photo-list');
    const dropzone = document.getElementById('q-dropzone');
    const success = document.getElementById('quote-success');
    let photos = []; // { file, url }

    // Same rules as the server
    function isValidPhone(value) {
        const phone = value.replace(/[\s().-]/g, '');
        return /^(\+351|00351)?[29]\d{8}$/.test(phone) || /^(\+|00)[1-9]\d{6,14}$/.test(phone);
    }
    const RULES = {
        name: v => (v.length >= 2 && v.length <= 100) || 'Indique o seu nome.',
        phone: v => (v.length <= 30 && isValidPhone(v)) || 'Indique um número de telefone válido (ex.: 912 345 678).',
        email: v => (v.length <= 254 && /^[^\s@<>"]+@[^\s@<>"]+\.[a-z]{2,}$/i.test(v)) || 'Indique um email válido (ex.: nome@exemplo.pt).',
        service: v => SERVICES.includes(v) || 'Selecione o serviço pretendido.',
        description: v => (v.length >= 10 && v.length <= 3000) || 'Descreva o trabalho (pelo menos 10 caracteres).'
    };

    function setFieldError(name, message) {
        const input = name === 'photos' ? photoInput : form.elements[name];
        const error = document.getElementById(`q-${name}-error`);
        error.textContent = message || '';
        error.hidden = !message;
        if (name === 'photos') {
            dropzone.classList.toggle('border-red-500', !!message);
            return;
        }
        input.setAttribute('aria-invalid', message ? 'true' : 'false');
        input.classList.toggle('border-red-500', !!message);
        input.classList.toggle('border-gray-300', !message);
    }

    function validateField(name) {
        const result = RULES[name](form.elements[name].value.trim());
        setFieldError(name, result === true ? '' : result);
        return result === true;
    }

    // Returns the first invalid field, or null
    function validateAll() {
        let firstInvalid = null;
        for (const name of Object.keys(RULES)) {
            if (!validateField(name) && !firstInvalid) firstInvalid = form.elements[name];
        }
        return firstInvalid;
    }

    // Check a field when leaving it; once it has an error, re-check while typing
    Object.keys(RULES).forEach(name => {
        const input = form.elements[name];
        input.addEventListener('blur', () => { if (input.value.trim()) validateField(name); });
        input.addEventListener(input.tagName === 'SELECT' ? 'change' : 'input', () => {
            if (input.getAttribute('aria-invalid') === 'true') validateField(name);
        });
    });

    // ---------- Photos ----------

    function renderPhotos() {
        photoList.innerHTML = '';
        photos.forEach((photo, i) => {
            const item = document.createElement('li');
            item.className = 'relative aspect-square rounded-lg overflow-hidden bg-gray-100';
            const img = document.createElement('img');
            img.src = photo.url;
            img.alt = `Fotografia ${i + 1}: ${photo.file.name}`;
            img.className = 'w-full h-full object-cover';
            const remove = document.createElement('button');
            remove.type = 'button';
            remove.className = 'absolute top-1 right-1 w-8 h-8 rounded-full bg-black/70 text-white flex items-center justify-center hover:bg-red-600 transition-colors';
            remove.setAttribute('aria-label', `Remover fotografia ${i + 1}`);
            remove.textContent = '✕';
            remove.addEventListener('click', () => {
                URL.revokeObjectURL(photo.url);
                photos.splice(i, 1);
                setFieldError('photos', '');
                renderPhotos();
            });
            item.append(img, remove);
            photoList.appendChild(item);
        });
    }

    function addPhotos(files) {
        let message = '';
        for (const file of files) {
            if (!file.type.startsWith('image/')) {
                message = `"${file.name}" não é uma fotografia.`;
                continue;
            }
            if (photos.length >= MAX_PHOTOS) {
                message = `Pode enviar no máximo ${MAX_PHOTOS} fotografias.`;
                break;
            }
            photos.push({ file, url: URL.createObjectURL(file) });
        }
        setFieldError('photos', message);
        renderPhotos();
    }

    photoInput.addEventListener('change', () => {
        addPhotos([...photoInput.files]);
        photoInput.value = '';
    });
    ['dragenter', 'dragover'].forEach(type => dropzone.addEventListener(type, e => {
        e.preventDefault();
        dropzone.classList.add('border-prime-yellow', 'bg-gray-50');
    }));
    ['dragleave', 'drop'].forEach(type => dropzone.addEventListener(type, () => {
        dropzone.classList.remove('border-prime-yellow', 'bg-gray-50');
    }));
    dropzone.addEventListener('drop', e => {
        e.preventDefault();
        addPhotos([...e.dataTransfer.files]);
    });

    // Resize to at most 1600px and encode as WebP (JPEG where WebP encoding is unavailable)
    async function shrinkPhoto(file) {
        const bitmap = await createImageBitmap(file);
        try {
            const scale = Math.min(1, PHOTO_MAX_SIDE / Math.max(bitmap.width, bitmap.height));
            const canvas = document.createElement('canvas');
            canvas.width = Math.round(bitmap.width * scale);
            canvas.height = Math.round(bitmap.height * scale);
            canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
            const toBlob = (type, quality) => new Promise(resolve => canvas.toBlob(resolve, type, quality));
            let blob = await toBlob('image/webp', 0.8);
            if (!blob || blob.type !== 'image/webp') blob = await toBlob('image/jpeg', 0.82);
            return blob;
        } finally {
            bitmap.close();
        }
    }

    // ---------- Submit ----------

    function setBusy(busy, label) {
        submitButton.disabled = busy;
        form.setAttribute('aria-busy', busy ? 'true' : 'false');
        submitLabel.textContent = label || 'Pedir orçamento';
    }

    function showFormError(message) {
        formError.textContent = message;
        formError.hidden = !message;
    }

    form.addEventListener('submit', async e => {
        e.preventDefault();
        showFormError('');
        const firstInvalid = validateAll();
        if (firstInvalid) {
            showFormError('Verifique os campos assinalados.');
            firstInvalid.focus();
            return;
        }

        const data = new FormData();
        for (const name of Object.keys(RULES)) data.append(name, form.elements[name].value.trim());
        data.append('website', form.elements.website.value);
        data.append('startedAt', String(startedAt));

        setBusy(true, photos.length ? 'A preparar fotografias...' : 'A enviar...');
        for (let i = 0; i < photos.length; i++) {
            let blob;
            try {
                blob = await shrinkPhoto(photos[i].file);
            } catch (err) {
                blob = null;
            }
            if (!blob || blob.size > MAX_PHOTO_BYTES) {
                setBusy(false);
                setFieldError('photos', `Não foi possível preparar a fotografia ${i + 1} ("${photos[i].file.name}"). Remova-a ou escolha outra.`);
                showFormError('Verifique os campos assinalados.');
                return;
            }
            data.append('photos', blob, `fotografia-${i + 1}`);
        }

        setBusy(true, 'A enviar...');
        let res;
        try {
            res = await fetch('/api/quote', { method: 'POST', body: data });
        } catch (err) {
            res = null;
        }
        setBusy(false);

        if (res && res.ok) {
            showSuccess(form.elements.name.value.trim());
            return;
        }
        let body = {};
        try { body = res ? await res.json() : {}; } catch (err) {}
        if (body.fields) {
            let first = null;
            for (const [name, message] of Object.entries(body.fields)) {
                setFieldError(name, message);
                if (!first) first = name === 'photos' ? photoInput : form.elements[name];
            }
            if (first && first !== photoInput) first.focus();
        }
        showFormError(body.error ||
            'Não foi possível enviar o pedido. Verifique a sua ligação e tente novamente, ou envie-nos um email para Prime.performance@outlook.pt.');
    });

    function showSuccess(name) {
        document.getElementById('quote-success-name').textContent = name ? `, ${name.split(/\s+/)[0]}` : '';
        form.hidden = true;
        success.hidden = false;
        const title = document.getElementById('quote-success-title');
        title.scrollIntoView({ behavior: 'smooth', block: 'center' });
        title.focus({ preventScroll: true });
    }

    document.getElementById('quote-new').addEventListener('click', () => {
        form.reset();
        photos.forEach(p => URL.revokeObjectURL(p.url));
        photos = [];
        renderPhotos();
        Object.keys(RULES).concat('photos').forEach(name => setFieldError(name, ''));
        showFormError('');
        success.hidden = true;
        form.hidden = false;
        form.elements.name.focus();
    });
})();
