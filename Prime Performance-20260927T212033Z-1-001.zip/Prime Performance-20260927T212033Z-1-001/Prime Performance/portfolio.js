// =============================================
// PRIME PERFORMANCE — PORTFOLIO (public)
// =============================================
// Renders the published projects from /api/projects into #projects-grid and
// shows each project in #project-viewer (gallery, before/after, description).
// Projects are real works added by the admin; nothing here is filled in by default.

const PrimePortfolio = (() => {
    const SERVICES = {
        'remodelacao': 'Remodelação',
        'construcao': 'Construção',
        'pintura': 'Pintura',
        'eletricidade': 'Eletricidade',
        'canalizacao': 'Canalização',
        'reparacoes-bricolagem': 'Reparações e bricolagem'
    };

    const grid = document.getElementById('projects-grid');
    const placeholder = grid.innerHTML;
    const viewer = document.getElementById('project-viewer');
    const viewerBody = document.getElementById('pv-body');
    let projects = [];
    let lastTrigger = null;

    function esc(value) {
        return String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }

    // "2025" or "2025-03" -> "2025" / "março de 2025"
    function formatDate(date) {
        if (!date) return '';
        const [year, month] = date.split('-');
        if (!month) return year;
        return new Date(Number(year), Number(month) - 1, 1).toLocaleDateString('pt-PT', { month: 'long', year: 'numeric' });
    }

    function altText(project, photo, index) {
        if (photo.alt) return photo.alt;
        if (photo.role === 'before') return project.title + ': antes da intervenção';
        if (photo.role === 'after') return project.title + ': depois da intervenção';
        return project.title + ': fotografia ' + (index + 1);
    }

    // Cover: first photo that is not a "before" shot
    function coverOf(project) {
        return project.photos.find(ph => ph.role !== 'before') || project.photos[0];
    }

    function img(project, photo, { src, lazy, classes }) {
        const index = project.photos.indexOf(photo);
        return `<img src="${esc(src)}" alt="${esc(altText(project, photo, index))}" width="${photo.width}" height="${photo.height}"` +
            `${lazy ? ' loading="lazy"' : ''} decoding="async" class="${classes}" />`;
    }

    function card(project, i) {
        const cover = coverOf(project);
        const service = SERVICES[project.service];
        return `
            <button type="button" data-project="${i}" aria-label="Ver projeto: ${esc(project.title)}" class="group relative overflow-hidden h-80 rounded-sm shadow-md bg-prime-black text-left w-full focus:outline-none focus-visible:ring-4 focus-visible:ring-prime-yellow">
                ${img(project, cover, { src: cover.thumb, lazy: true, classes: 'w-full h-full object-cover transition-transform duration-700 group-hover:scale-110' })}
                <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent flex flex-col justify-end p-6">
                    ${service ? `<span class="text-prime-yellow text-xs font-bold uppercase tracking-wider mb-2">${esc(service)}</span>` : ''}
                    <h3 class="text-white font-bold text-lg leading-snug">${esc(project.title)}</h3>
                    ${project.location ? `<span class="text-gray-300 text-sm mt-1">${esc(project.location)}</span>` : ''}
                </div>
            </button>`;
    }

    function render() {
        if (projects.length) {
            grid.innerHTML = projects.map(card).join('');
        } else if (grid.innerHTML !== placeholder) {
            grid.innerHTML = placeholder;
            if (window.lucide) lucide.createIcons();
        }
    }

    async function load() {
        try {
            const res = await fetch('/api/projects', { cache: 'no-store' });
            if (!res.ok) return;
            projects = await res.json();
            render();
        } catch (e) {
            // Server unavailable: keep the placeholders
        }
    }

    // ---------- Viewer ----------

    function beforeAfter(project) {
        const before = project.photos.find(ph => ph.role === 'before');
        const after = project.photos.find(ph => ph.role === 'after');
        if (!before || !after) return '';
        const figure = (photo, label) => `
            <figure class="relative">
                ${img(project, photo, { src: photo.src, lazy: false, classes: 'w-full h-auto rounded-sm bg-white/5' })}
                <figcaption class="absolute top-3 left-3 bg-prime-yellow text-prime-black text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-sm">${label}</figcaption>
            </figure>`;
        return `
            <section>
                <h3 class="text-white text-lg font-bold mb-4">Antes e depois</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">${figure(before, 'Antes')}${figure(after, 'Depois')}</div>
            </section>`;
    }

    // Gallery: every photo not already shown in the before/after pair
    function galleryPhotos(project) {
        const hasPair = project.photos.some(ph => ph.role === 'before') && project.photos.some(ph => ph.role === 'after');
        return hasPair ? project.photos.filter(ph => ph.role === 'gallery') : project.photos;
    }

    function gallery(project) {
        const photos = galleryPhotos(project);
        if (!photos.length) return '';
        // The main photo (#pv-main) is filled by showPhoto()
        const thumbs = photos.length > 1 ? `
            <div class="flex gap-2 overflow-x-auto pb-2" role="list">
                ${photos.map((ph, i) => `
                    <button type="button" role="listitem" data-photo="${i}" aria-label="Ver fotografia ${i + 1} de ${photos.length}" class="pv-thumb flex-shrink-0 w-20 h-20 sm:w-24 sm:h-24 rounded-sm overflow-hidden border-2 border-transparent focus:outline-none focus-visible:border-white">
                        ${img(project, ph, { src: ph.thumb, lazy: true, classes: 'w-full h-full object-cover' })}
                    </button>`).join('')}
            </div>` : '';
        return `
            <section>
                <h3 class="text-white text-lg font-bold mb-4">Galeria</h3>
                <figure class="relative mb-3">
                    <div id="pv-main" class="bg-white/5 rounded-sm"></div>
                    <figcaption id="pv-main-label" class="absolute top-3 left-3 bg-prime-yellow text-prime-black text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-sm" hidden></figcaption>
                    ${photos.length > 1 ? `
                    <button type="button" id="pv-prev" aria-label="Fotografia anterior" class="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-prime-yellow hover:text-prime-black transition-colors"><i data-lucide="chevron-left" class="w-6 h-6"></i></button>
                    <button type="button" id="pv-next" aria-label="Fotografia seguinte" class="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-prime-yellow hover:text-prime-black transition-colors"><i data-lucide="chevron-right" class="w-6 h-6"></i></button>` : ''}
                </figure>
                ${thumbs}
            </section>`;
    }

    let current = { project: null, photos: [], index: 0 };

    function showPhoto(index) {
        const { project, photos } = current;
        if (!photos.length) return;
        current.index = (index + photos.length) % photos.length;
        const photo = photos[current.index];
        document.getElementById('pv-main').innerHTML =
            img(project, photo, { src: photo.src, lazy: false, classes: 'w-full h-auto max-h-[75vh] object-contain mx-auto rounded-sm' });
        const label = document.getElementById('pv-main-label');
        const text = photo.role === 'before' ? 'Antes' : photo.role === 'after' ? 'Depois' : '';
        label.textContent = text;
        label.hidden = !text;
        viewer.querySelectorAll('.pv-thumb').forEach((b, i) => {
            b.classList.toggle('border-prime-yellow', i === current.index);
            b.setAttribute('aria-current', i === current.index ? 'true' : 'false');
        });
    }

    function open(i, trigger) {
        const project = projects[i];
        if (!project) return;
        lastTrigger = trigger || null;
        const service = SERVICES[project.service];
        document.getElementById('pv-service').textContent = service || '';
        document.getElementById('pv-title').textContent = project.title;

        const meta = [];
        if (project.location) meta.push(`<span class="inline-flex items-center gap-2"><i data-lucide="map-pin" class="w-4 h-4 text-prime-yellow"></i>${esc(project.location)}</span>`);
        if (project.date) meta.push(`<span class="inline-flex items-center gap-2"><i data-lucide="calendar" class="w-4 h-4 text-prime-yellow"></i>${esc(formatDate(project.date))}</span>`);
        document.getElementById('pv-meta').innerHTML = meta.join('');

        const description = project.description
            ? `<section class="max-w-3xl">${project.description.split(/\n+/).map(p => `<p class="text-gray-300 text-lg leading-relaxed mb-4">${esc(p)}</p>`).join('')}</section>`
            : '';
        const links = `
            <div class="flex flex-col sm:flex-row gap-4 pt-2">
                <a href="#contact" data-close class="bg-prime-yellow text-prime-black px-8 py-4 rounded-sm font-bold uppercase tracking-wide hover:bg-white transition-all flex items-center justify-center gap-2">
                    Pedir orçamento <i data-lucide="arrow-right" class="w-5 h-5"></i>
                </a>
                ${service ? `<a href="/servicos/${esc(project.service)}/" class="border-2 border-white/30 text-white px-8 py-4 rounded-sm font-bold uppercase tracking-wide hover:bg-white hover:text-prime-black transition-all flex items-center justify-center">Serviço de ${esc(service.toLowerCase())}</a>` : ''}
            </div>`;
        viewerBody.innerHTML = description + beforeAfter(project) + gallery(project) + links;

        current = { project, photos: galleryPhotos(project), index: 0 };
        if (current.photos.length) showPhoto(0);

        viewer.hidden = false;
        setBackgroundInert(true);
        document.body.style.overflow = 'hidden';
        if (window.lucide) lucide.createIcons();
        viewer.scrollTop = 0;
        document.getElementById('pv-close').focus();
    }

    // While the viewer is open, the page behind it cannot be reached with Tab or by screen readers
    function setBackgroundInert(inert) {
        for (const el of document.body.children) {
            if (el !== viewer && el.tagName !== 'SCRIPT') el.inert = inert;
        }
    }

    function close() {
        if (viewer.hidden) return;
        viewer.hidden = true;
        setBackgroundInert(false);
        viewerBody.innerHTML = '';
        document.body.style.overflow = '';
        if (lastTrigger) lastTrigger.focus();
    }

    grid.addEventListener('click', e => {
        const button = e.target.closest('[data-project]');
        if (button) open(Number(button.dataset.project), button);
    });
    document.getElementById('pv-close').addEventListener('click', close);
    viewer.addEventListener('click', e => {
        if (e.target.closest('[data-close]')) return close();
        if (e.target.closest('#pv-prev')) return showPhoto(current.index - 1);
        if (e.target.closest('#pv-next')) return showPhoto(current.index + 1);
        const thumb = e.target.closest('[data-photo]');
        if (thumb) return showPhoto(Number(thumb.dataset.photo));
        if (e.target === viewer) close();
    });
    document.addEventListener('keydown', e => {
        if (viewer.hidden) return;
        if (e.key === 'Escape') close();
        if (e.key === 'ArrowLeft') showPhoto(current.index - 1);
        if (e.key === 'ArrowRight') showPhoto(current.index + 1);
    });

    load();
    return { SERVICES, esc, load, open, close };
})();
