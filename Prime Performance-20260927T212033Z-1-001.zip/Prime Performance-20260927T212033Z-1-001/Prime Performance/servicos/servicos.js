// Shared script for the service pages (/servicos/*/)

// Initialize Icons
lucide.createIcons();

// Set Copyright Year
document.getElementById('year').textContent = new Date().getFullYear();

// Mobile Menu Toggle
const menuBtn = document.getElementById('menu-btn');
const mobileMenu = document.getElementById('mobile-menu');

function setMobileMenu(open) {
    mobileMenu.classList.toggle('open', open);
    menuBtn.setAttribute('aria-expanded', open);
    menuBtn.innerHTML = `<i data-lucide="${open ? 'x' : 'menu'}" class="w-7 h-7"></i>`;
    lucide.createIcons();
}
menuBtn.addEventListener('click', () => setMobileMenu(!mobileMenu.classList.contains('open')));
document.querySelectorAll('.mobile-link').forEach(link => link.addEventListener('click', () => setMobileMenu(false)));
document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && mobileMenu.classList.contains('open')) {
        setMobileMenu(false);
        menuBtn.focus();
    }
});

// Logo uploaded in the admin panel (same as the homepage)
fetch('/api/images', { cache: 'no-store' })
    .then(res => (res.ok ? res.json() : {}))
    .then(images => {
        if (!images.logo) return;
        ['site-logo', 'footer-logo'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.src = images.logo;
        });
    })
    .catch(() => {});
