// Used by build.mjs to compile the site's CSS (same settings as the inline tailwind.config in the pages)
module.exports = {
    content: ["./Prime Performance/**/*.{html,js}"],
    theme: {
        extend: {
            colors: {
                prime: {
                    yellow: "#F2B50C",
                    black: "#111111",
                    dark: "#0a0a0a",
                    gray: "#f4f4f4",
                    // Darker gold for text on light backgrounds (contrast 3.6:1+; the brand yellow is 1.7:1)
                    gold: "#A67800",
                },
            },
            fontFamily: {
                sans: ["Inter", "sans-serif"],
            },
        },
    },
};
