// =============================================
// PRIME PERFORMANCE — SERVER API (Netlify Function)
// =============================================
//
// Public:
//   GET    /api/images                -> { slotId: url } for images uploaded by the admin
//   GET    /api/images/:slot          -> image bytes
//   GET    /api/projects              -> published portfolio projects
//   GET    /api/projects/:id/photos/:photoId[/thumb] -> photo bytes
//   POST   /api/quote                 multipart: name, phone, email, service, description, photos (0-5),
//                                     website (honeypot), startedAt -> stores the request and emails it
//
// Admin (every route below login/logout requires a valid session cookie):
//   POST   /api/admin/login           { password } -> sets HttpOnly session cookie
//   POST   /api/admin/logout          -> revokes the session
//   GET    /api/admin/session         -> 200 if logged in, 401 otherwise
//   PUT    /api/admin/images/:slot    raw image body (JPG, PNG, WebP, GIF)
//   DELETE /api/admin/images/:slot
//   DELETE /api/admin/images
//   GET    /api/admin/projects        -> all projects, drafts included
//   POST   /api/admin/projects        { title, description, service, location, date } -> new draft
//   PUT    /api/admin/projects/:id    same fields + published + photos [{ id, alt, role }] (order = display order)
//   DELETE /api/admin/projects/:id
//   POST   /api/admin/projects/:id/photos           multipart: full, thumb (optional), role, width, height, alt
//   DELETE /api/admin/projects/:id/photos/:photoId
//   GET    /api/admin/projects/:id/photos/:photoId[/thumb] -> photo preview, drafts included
//   GET    /api/admin/quotes          -> quote requests, newest first
//   GET    /api/admin/quotes/:id/photos/:photoId
//   DELETE /api/admin/quotes/:id
//
// Environment variables (Netlify > Site configuration > Environment variables):
//   ADMIN_PASSWORD    required, at least 12 characters. The admin area stays locked while it is missing.
//   RESEND_API_KEY    API key from resend.com, used to email each quote request. Without it requests
//                     are still saved and visible in the admin panel, but no email is sent.
//   QUOTE_EMAIL_TO    optional, recipient of quote requests (default: Prime.performance@outlook.pt)
//   QUOTE_EMAIL_FROM  optional, sender (default: "Prime Performance <onboarding@resend.dev>", which
//                     Resend only delivers to the email address of the Resend account itself)

import { getStore } from "@netlify/blobs";
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";

export const config = { path: "/api/*" };

const SLOTS = new Set(["logo", "hero"]);
const MAX_IMAGE_BYTES = 4 * 1024 * 1024;
const MAX_THUMB_BYTES = 1024 * 1024;

// Portfolio: only real projects entered by the admin. Services match the pages in /servicos/.
const SERVICES = new Set(["remodelacao", "construcao", "pintura", "eletricidade", "canalizacao", "reparacoes-bricolagem"]);
const PHOTO_ROLES = new Set(["gallery", "before", "after"]);
const MAX_PHOTOS = 20;
const MAX_PROJECTS = 100;
const ID_PATTERN = /^[a-f0-9]{16}$/;
const DATE_PATTERN = /^\d{4}(-(0[1-9]|1[0-2]))?$/;

// Quote requests
const SERVICE_NAMES = {
    "remodelacao": "Remodelação", "construcao": "Construção", "pintura": "Pintura", "eletricidade": "Eletricidade",
    "canalizacao": "Canalização", "reparacoes-bricolagem": "Reparações e bricolagem", "outro": "Outro / não sei",
};
const QUOTE_PHOTO_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);
const MAX_QUOTE_PHOTOS = 5;
const MAX_QUOTE_PHOTO_BYTES = 2 * 1024 * 1024;
const MAX_QUOTE_BODY_BYTES = 5.5 * 1024 * 1024; // Netlify Functions accept up to 6 MB per request
const MAX_QUOTES_PER_HOUR = 5;
const MIN_FILL_MS = 3000;
const DEFAULT_QUOTE_EMAIL = "Prime.performance@outlook.pt";
const EMAIL_PATTERN = /^[^\s@<>"]+@[^\s@<>"]+\.[a-z]{2,}$/i;

// Same rules as the form (/quote.js): Portuguese numbers (9 digits, optional +351) or international format
export function isValidPhone(value) {
    const phone = String(value).replace(/[\s().-]/g, "");
    return /^(\+351|00351)?[29]\d{8}$/.test(phone) || /^(\+|00)[1-9]\d{6,14}$/.test(phone);
}
const MIN_PASSWORD_LENGTH = 12;
const SESSION_TTL_MS = 8 * 60 * 60 * 1000;
const MAX_FAILED_LOGINS = 5;
const LOCKOUT_MS = 15 * 60 * 1000;
const COOKIE = "pp_admin";
const COOKIE_ATTRS = "Path=/api/admin; HttpOnly; Secure; SameSite=Strict";
const TOKEN_PATTERN = /^[a-f0-9]{64}$/;

// Accepted image types, each checked against the file's real signature (SVG is excluded on purpose)
const ascii = (b, start, end) => String.fromCharCode(...b.subarray(start, end));
const IMAGE_TYPES = {
    "image/jpeg": b => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff,
    "image/png": b => b[0] === 0x89 && ascii(b, 1, 4) === "PNG",
    "image/webp": b => ascii(b, 0, 4) === "RIFF" && ascii(b, 8, 12) === "WEBP",
    "image/gif": b => ascii(b, 0, 4) === "GIF8",
};

export function createHandler(openStore, env = process.env, fetchImpl = fetch) {
    return async function handler(req, context) {
        try {
            return await route(req, context, openStore, env, fetchImpl);
        } catch (err) {
            console.error(err);
            return json(500, { error: "Erro interno do servidor." });
        }
    };
}

export default createHandler(name => getStore({ name, consistency: "strong" }));

async function route(req, context, openStore, env, fetchImpl) {
    const url = new URL(req.url);
    const path = url.pathname.replace(/\/+$/, "");
    const method = req.method;
    const images = openStore("site-images");

    // ---- Public routes ----
    if (path === "/api/images" && method === "GET") return listImages(images);
    let match = path.match(/^\/api\/images\/([a-z0-9]+)$/);
    if (match && method === "GET") return serveImage(images, match[1], url);

    const portfolio = openStore("portfolio");
    const photos = openStore("portfolio-photos");
    if (path === "/api/projects" && method === "GET") {
        const projects = await loadProjects(portfolio);
        return json(200, projects.filter(p => p.published).map(p => projectView(p, "/api/projects")));
    }
    match = path.match(/^\/api\/projects\/([a-f0-9]{16})\/photos\/([a-f0-9]{16})(\/thumb)?$/);
    if (match && method === "GET") return servePhoto(portfolio, photos, match[1], match[2], match[3] ? "thumb" : "full");

    const quotes = openStore("quotes");
    const quotePhotos = openStore("quote-photos");
    if (path === "/api/quote" && method === "POST") {
        if (!isSameOrigin(req, url)) return json(403, { error: "Pedido recusado." });
        return submitQuote(req, context, { quotes, quotePhotos, admin: openStore("admin") }, env, fetchImpl);
    }

    if (!path.startsWith("/api/admin/")) return json(404, { error: "Não encontrado." });

    // ---- Admin routes ----
    // Reject cross-site requests that change state (CSRF), on top of the SameSite cookie
    if (method !== "GET" && !isSameOrigin(req, url)) return json(403, { error: "Pedido recusado." });

    const admin = openStore("admin");
    if (path === "/api/admin/login" && method === "POST") return login(req, context, admin, env);
    if (path === "/api/admin/logout" && method === "POST") return logout(req, admin);

    if (!(await getSession(req, admin))) return json(401, { error: "Sessão inválida ou expirada." });

    if (path === "/api/admin/session" && method === "GET") return json(200, { authenticated: true });
    if (path === "/api/admin/images" && method === "DELETE") {
        await Promise.all([...SLOTS].map(slot => images.delete(slot)));
        return json(200, { ok: true });
    }
    match = path.match(/^\/api\/admin\/images\/([a-z0-9]+)$/);
    if (match && SLOTS.has(match[1])) {
        if (method === "PUT") return uploadImage(req, images, match[1]);
        if (method === "DELETE") {
            await images.delete(match[1]);
            return json(200, { ok: true });
        }
    }

    if (path === "/api/admin/projects") {
        if (method === "GET") return json(200, (await loadProjects(portfolio)).map(p => projectView(p, ADMIN_PROJECTS)));
        if (method === "POST") return createProject(req, portfolio);
    }
    // Admin preview of photos, drafts included
    match = path.match(/^\/api\/admin\/projects\/([a-f0-9]{16})\/photos\/([a-f0-9]{16})(\/thumb)?$/);
    if (match && method === "GET") {
        const variant = match[3] ? "thumb" : "full";
        return imageResponse(await photos.getWithMetadata(`${match[1]}/${match[2]}/${variant}`, { type: "arrayBuffer" }), false);
    }
    match = path.match(/^\/api\/admin\/projects\/([a-f0-9]{16})$/);
    if (match) {
        if (method === "PUT") return updateProject(req, portfolio, match[1]);
        if (method === "DELETE") return deleteProject(portfolio, photos, match[1]);
    }
    match = path.match(/^\/api\/admin\/projects\/([a-f0-9]{16})\/photos$/);
    if (match && method === "POST") return addPhoto(req, portfolio, photos, match[1]);
    match = path.match(/^\/api\/admin\/projects\/([a-f0-9]{16})\/photos\/([a-f0-9]{16})$/);
    if (match && method === "DELETE") return deletePhoto(portfolio, photos, match[1], match[2]);

    if (path === "/api/admin/quotes" && method === "GET") return listQuotes(quotes);
    match = path.match(/^\/api\/admin\/quotes\/([a-f0-9]{16})$/);
    if (match && method === "DELETE") return deleteQuote(quotes, quotePhotos, match[1]);
    match = path.match(/^\/api\/admin\/quotes\/([a-f0-9]{16})\/photos\/([a-f0-9]{16})$/);
    if (match && method === "GET") {
        return imageResponse(await quotePhotos.getWithMetadata(`${match[1]}/${match[2]}`, { type: "arrayBuffer" }), false);
    }

    return json(404, { error: "Não encontrado." });
}

// ---------- Public images ----------

async function listImages(store) {
    const { blobs } = await store.list();
    const result = {};
    for (const blob of blobs) {
        if (SLOTS.has(blob.key)) result[blob.key] = `/api/images/${blob.key}?v=${encodeURIComponent(blob.etag)}`;
    }
    return json(200, result);
}

async function serveImage(store, slot, url) {
    if (!SLOTS.has(slot)) return json(404, { error: "Não encontrado." });
    const entry = await store.getWithMetadata(slot, { type: "arrayBuffer" });
    // Versioned URLs (?v=etag) never change, so they can be cached for good
    return imageResponse(entry, url.searchParams.has("v"));
}

function imageResponse(entry, immutable) {
    const type = entry?.metadata?.contentType;
    if (!entry || !IMAGE_TYPES[type]) return json(404, { error: "Não encontrado." });
    return new Response(entry.data, {
        headers: {
            "Content-Type": type,
            "X-Content-Type-Options": "nosniff",
            "Content-Security-Policy": "default-src 'none'",
            "Cache-Control": immutable ? "public, max-age=31536000, immutable" : "no-cache",
        },
    });
}

async function uploadImage(req, store, slot) {
    const type = (req.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
    if (Number(req.headers.get("content-length") || 0) > MAX_IMAGE_BYTES) return tooLarge();
    const data = await req.arrayBuffer();
    const error = checkImage(type, data, MAX_IMAGE_BYTES);
    if (error) return error;
    await store.set(slot, data, { metadata: { contentType: type } });
    return json(200, { ok: true });
}

// Returns an error response, or null when the bytes are a real image of an accepted type
function checkImage(type, data, maxBytes) {
    const isValid = IMAGE_TYPES[type];
    if (!isValid) return json(415, { error: "Formato não suportado. Use JPG, PNG, WebP ou GIF." });
    if (data.byteLength > maxBytes) return tooLarge();
    if (data.byteLength === 0 || !isValid(new Uint8Array(data))) {
        return json(415, { error: "O ficheiro não é uma imagem válida." });
    }
    return null;
}

const tooLarge = () => json(413, { error: "Imagem demasiado grande (máx. 4 MB)." });

// ---------- Portfolio ----------

async function loadProjects(store) {
    return (await store.get("projects", { type: "json" })) || [];
}

async function saveProjects(store, projects) {
    await store.setJSON("projects", projects);
}

const newId = () => randomBytes(8).toString("hex");
const badRequest = error => json(400, { error });
const notFound = () => json(404, { error: "Não encontrado." });

const ADMIN_PROJECTS = "/api/admin/projects";

// Shape sent to the browser. Public and admin views differ only in where photos are served from.
function projectView(p, base) {
    return {
        id: p.id,
        title: p.title,
        description: p.description,
        service: p.service,
        location: p.location,
        date: p.date,
        published: p.published,
        photos: p.photos.map(ph => {
            const src = `${base}/${p.id}/photos/${ph.id}`;
            return { id: ph.id, alt: ph.alt, role: ph.role, width: ph.width, height: ph.height, src, thumb: ph.hasThumb ? src + "/thumb" : src };
        }),
    };
}

async function readJson(req) {
    if (Number(req.headers.get("content-length") || 0) > 64 * 1024) return null;
    try {
        const body = await req.json();
        return body && typeof body === "object" && !Array.isArray(body) ? body : null;
    } catch {
        return null;
    }
}

// Validates the editable text fields. Returns { fields } or { error }.
function readFields(body) {
    const text = (key, max, label) => {
        const value = body[key] ?? "";
        if (typeof value !== "string") throw `${label} inválido.`;
        const trimmed = value.trim();
        if (trimmed.length > max) throw `${label}: máximo de ${max} caracteres.`;
        return trimmed;
    };
    try {
        const fields = {
            title: text("title", 120, "Título"),
            description: text("description", 2000, "Descrição"),
            service: text("service", 40, "Serviço"),
            location: text("location", 120, "Localização"),
            date: text("date", 7, "Data"),
        };
        if (!fields.title) throw "O título é obrigatório.";
        if (fields.service && !SERVICES.has(fields.service)) throw "Serviço inválido.";
        if (fields.date && !DATE_PATTERN.test(fields.date)) throw "Data inválida (use AAAA ou AAAA-MM).";
        return { fields };
    } catch (error) {
        return { error };
    }
}

async function createProject(req, store) {
    const body = await readJson(req);
    if (!body) return badRequest("Pedido inválido.");
    const { fields, error } = readFields(body);
    if (error) return badRequest(error);
    const projects = await loadProjects(store);
    if (projects.length >= MAX_PROJECTS) return badRequest(`Limite de ${MAX_PROJECTS} projetos atingido.`);
    const project = { id: newId(), ...fields, published: false, photos: [], created: Date.now() };
    projects.unshift(project);
    await saveProjects(store, projects);
    return json(201, projectView(project, ADMIN_PROJECTS));
}

async function updateProject(req, store, id) {
    const body = await readJson(req);
    if (!body) return badRequest("Pedido inválido.");
    const { fields, error } = readFields(body);
    if (error) return badRequest(error);

    const projects = await loadProjects(store);
    const project = projects.find(p => p.id === id);
    if (!project) return notFound();

    // Photos: same set as stored, possibly reordered, with new alt text / role
    const incoming = Array.isArray(body.photos) ? body.photos : [];
    const byId = new Map(project.photos.map(ph => [ph.id, ph]));
    if (incoming.length !== byId.size || new Set(incoming.map(ph => ph?.id)).size !== byId.size || !incoming.every(ph => byId.has(ph?.id))) {
        return badRequest("A lista de fotografias não corresponde ao projeto. Recarregue a página.");
    }
    const photos = [];
    for (const ph of incoming) {
        const alt = typeof ph.alt === "string" ? ph.alt.trim() : "";
        if (alt.length > 200) return badRequest("Texto alternativo: máximo de 200 caracteres.");
        if (!PHOTO_ROLES.has(ph.role)) return badRequest("Tipo de fotografia inválido.");
        photos.push({ ...byId.get(ph.id), alt, role: ph.role });
    }
    const roleError = checkRoles(photos);
    if (roleError) return badRequest(roleError);

    const published = body.published === true;
    if (published && photos.length === 0) return badRequest("Adicione pelo menos uma fotografia antes de publicar.");

    Object.assign(project, fields, { photos, published });
    await saveProjects(store, projects);
    return json(200, projectView(project, ADMIN_PROJECTS));
}

function checkRoles(photos) {
    if (photos.filter(ph => ph.role === "before").length > 1) return "Só pode existir uma fotografia \"Antes\" por projeto.";
    if (photos.filter(ph => ph.role === "after").length > 1) return "Só pode existir uma fotografia \"Depois\" por projeto.";
    return null;
}

async function deleteProject(store, photoStore, id) {
    const projects = await loadProjects(store);
    const project = projects.find(p => p.id === id);
    if (!project) return notFound();
    await Promise.all(project.photos.flatMap(ph => [photoStore.delete(`${id}/${ph.id}/full`), photoStore.delete(`${id}/${ph.id}/thumb`)]));
    await saveProjects(store, projects.filter(p => p !== project));
    return json(200, { ok: true });
}

async function addPhoto(req, store, photoStore, id) {
    if (Number(req.headers.get("content-length") || 0) > MAX_IMAGE_BYTES + MAX_THUMB_BYTES + 64 * 1024) return tooLarge();
    const projects = await loadProjects(store);
    const project = projects.find(p => p.id === id);
    if (!project) return notFound();
    if (project.photos.length >= MAX_PHOTOS) return badRequest(`Máximo de ${MAX_PHOTOS} fotografias por projeto.`);

    let form;
    try {
        form = await req.formData();
    } catch {
        return badRequest("Pedido inválido.");
    }
    const role = form.get("role") || "gallery";
    if (!PHOTO_ROLES.has(role)) return badRequest("Tipo de fotografia inválido.");
    const width = Number(form.get("width"));
    const height = Number(form.get("height"));
    if (![width, height].every(n => Number.isInteger(n) && n > 0 && n <= 10000)) return badRequest("Dimensões inválidas.");
    const alt = String(form.get("alt") || "").trim();
    if (alt.length > 200) return badRequest("Texto alternativo: máximo de 200 caracteres.");

    const full = form.get("full");
    const thumb = form.get("thumb");
    if (!(full instanceof Blob)) return badRequest("Fotografia em falta.");
    const fullData = await full.arrayBuffer();
    let error = checkImage(full.type, fullData, MAX_IMAGE_BYTES);
    if (error) return error;
    let thumbData = null;
    if (thumb instanceof Blob) {
        thumbData = await thumb.arrayBuffer();
        error = checkImage(thumb.type, thumbData, MAX_THUMB_BYTES);
        if (error) return error;
    }

    const photo = { id: newId(), alt, role, width, height, hasThumb: !!thumbData };
    const roleError = checkRoles([...project.photos, photo]);
    if (roleError) return badRequest(roleError);

    await photoStore.set(`${id}/${photo.id}/full`, fullData, { metadata: { contentType: full.type } });
    if (thumbData) await photoStore.set(`${id}/${photo.id}/thumb`, thumbData, { metadata: { contentType: thumb.type } });
    project.photos.push(photo);
    await saveProjects(store, projects);
    return json(201, projectView(project, ADMIN_PROJECTS));
}

async function deletePhoto(store, photoStore, id, photoId) {
    const projects = await loadProjects(store);
    const project = projects.find(p => p.id === id);
    if (!project || !project.photos.some(ph => ph.id === photoId)) return notFound();
    await photoStore.delete(`${id}/${photoId}/full`);
    await photoStore.delete(`${id}/${photoId}/thumb`);
    project.photos = project.photos.filter(ph => ph.id !== photoId);
    // A published project always has at least one photo
    if (project.photos.length === 0) project.published = false;
    await saveProjects(store, projects);
    return json(200, projectView(project, ADMIN_PROJECTS));
}

// Photos of drafts stay private; photo ids never change content, so they cache for good
async function servePhoto(store, photoStore, id, photoId, variant) {
    const project = (await loadProjects(store)).find(p => p.id === id);
    if (!project?.published || !project.photos.some(ph => ph.id === photoId)) return notFound();
    return imageResponse(await photoStore.getWithMetadata(`${id}/${photoId}/${variant}`, { type: "arrayBuffer" }), true);
}

// ---------- Quote requests ----------

async function submitQuote(req, context, { quotes, quotePhotos, admin }, env, fetchImpl) {
    if (Number(req.headers.get("content-length") || 0) > MAX_QUOTE_BODY_BYTES) {
        return json(413, { error: "O pedido é demasiado grande. Envie menos fotografias.", fields: { photos: "Envie menos fotografias." } });
    }

    // At most MAX_QUOTES_PER_HOUR submissions per IP
    const ip = context?.ip || req.headers.get("x-nf-client-connection-ip") || "unknown";
    const limitKey = "quote-attempts/" + sha256(ip);
    const now = Date.now();
    let attempts = await admin.get(limitKey, { type: "json" });
    if (!attempts || now - attempts.first > 60 * 60 * 1000) attempts = { count: 0, first: now };
    if (attempts.count >= MAX_QUOTES_PER_HOUR) {
        return json(429, { error: `Recebemos vários pedidos seguidos a partir desta ligação. Tente mais tarde ou envie um email para ${DEFAULT_QUOTE_EMAIL}.` });
    }
    attempts.count += 1;
    await admin.setJSON(limitKey, attempts);

    let form;
    try {
        form = await req.formData();
    } catch {
        return badRequest("Pedido inválido.");
    }

    // Spam traps (hidden field filled in, or form sent faster than a person can type): pretend it worked, store nothing
    const startedRaw = form.get("startedAt");
    const startedAt = typeof startedRaw === "string" && startedRaw !== "" ? Number(startedRaw) : NaN;
    if (String(form.get("website") ?? "") !== "" || !Number.isFinite(startedAt) || now - startedAt < MIN_FILL_MS) {
        return json(200, { ok: true });
    }

    const text = key => String(form.get(key) ?? "").trim();
    const data = { name: text("name"), phone: text("phone"), email: text("email"), service: text("service"), description: text("description") };
    const fields = {};
    if (data.name.length < 2 || data.name.length > 100) fields.name = "Indique o seu nome.";
    if (data.phone.length > 30 || !isValidPhone(data.phone)) fields.phone = "Indique um número de telefone válido (ex.: 912 345 678).";
    if (data.email.length > 254 || !EMAIL_PATTERN.test(data.email)) fields.email = "Indique um email válido (ex.: nome@exemplo.pt).";
    if (!Object.hasOwn(SERVICE_NAMES, data.service)) fields.service = "Selecione o serviço pretendido.";
    if (data.description.length < 10 || data.description.length > 3000) fields.description = "Descreva o trabalho (entre 10 e 3000 caracteres).";

    const files = form.getAll("photos").filter(f => f instanceof Blob && f.size > 0);
    const photoData = [];
    if (files.length > MAX_QUOTE_PHOTOS) fields.photos = `Envie no máximo ${MAX_QUOTE_PHOTOS} fotografias.`;
    else {
        for (const file of files) {
            if (file.size > MAX_QUOTE_PHOTO_BYTES) {
                fields.photos = "Cada fotografia pode ter no máximo 2 MB.";
                break;
            }
            const bytes = await file.arrayBuffer();
            if (!QUOTE_PHOTO_TYPES.has(file.type) || !IMAGE_TYPES[file.type](new Uint8Array(bytes))) {
                fields.photos = "Só são aceites fotografias JPG, PNG ou WebP.";
                break;
            }
            photoData.push({ id: newId(), type: file.type, data: bytes });
        }
    }
    if (Object.keys(fields).length) return json(400, { error: "Verifique os campos assinalados.", fields });

    // Save first, so the request is never lost even if the email fails
    const quote = {
        id: newId(),
        created: now,
        ...data,
        photos: photoData.map(p => ({ id: p.id, type: p.type, size: p.data.byteLength })),
        emailed: false,
    };
    for (const p of photoData) await quotePhotos.set(`${quote.id}/${p.id}`, p.data, { metadata: { contentType: p.type } });
    await quotes.setJSON(quote.id, quote);

    quote.emailed = await sendQuoteEmail(quote, photoData, env, fetchImpl);
    if (quote.emailed) await quotes.setJSON(quote.id, quote);
    return json(200, { ok: true });
}

async function sendQuoteEmail(quote, photoData, env, fetchImpl) {
    if (!env.RESEND_API_KEY) {
        console.warn("RESEND_API_KEY is not set: quote request saved without sending an email");
        return false;
    }
    const service = SERVICE_NAMES[quote.service];
    const rows = [
        ["Nome", quote.name],
        ["Telefone", quote.phone],
        ["Email", quote.email],
        ["Serviço", service],
        ["Data do pedido", new Date(quote.created).toLocaleString("pt-PT", { timeZone: "Europe/Lisbon" })],
    ];
    const text = rows.map(([k, v]) => `${k}: ${v}`).join("\n") +
        `\n\nDescrição:\n${quote.description}\n\nFotografias anexadas: ${photoData.length}`;
    const html = `<h2>Novo pedido de orçamento</h2><table>` +
        rows.map(([k, v]) => `<tr><th align="left" style="padding:4px 16px 4px 0">${escapeHtml(k)}</th><td>${escapeHtml(v)}</td></tr>`).join("") +
        `</table><h3>Descrição</h3><p style="white-space:pre-wrap">${escapeHtml(quote.description)}</p>` +
        `<p>Fotografias anexadas: ${photoData.length}</p>`;
    const extension = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp" };
    try {
        const res = await fetchImpl("https://api.resend.com/emails", {
            method: "POST",
            headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, "Content-Type": "application/json" },
            body: JSON.stringify({
                from: env.QUOTE_EMAIL_FROM || "Prime Performance <onboarding@resend.dev>",
                to: [env.QUOTE_EMAIL_TO || DEFAULT_QUOTE_EMAIL],
                reply_to: quote.email,
                subject: `Pedido de orçamento: ${service} - ${quote.name}`.replace(/[\r\n]+/g, " "),
                text,
                html,
                attachments: photoData.map((p, i) => ({
                    filename: `fotografia-${i + 1}.${extension[p.type]}`,
                    content: Buffer.from(p.data).toString("base64"),
                })),
            }),
        });
        if (!res.ok) {
            console.error("Resend error", res.status, await res.text());
            return false;
        }
        return true;
    } catch (err) {
        console.error("Resend request failed", err);
        return false;
    }
}

async function listQuotes(store) {
    const { blobs } = await store.list();
    const items = (await Promise.all(blobs.map(b => store.get(b.key, { type: "json" })))).filter(Boolean);
    items.sort((a, b) => b.created - a.created);
    return json(200, items.map(q => ({
        ...q,
        photos: q.photos.map(ph => ({ ...ph, src: `/api/admin/quotes/${q.id}/photos/${ph.id}` })),
    })));
}

async function deleteQuote(store, photoStore, id) {
    const quote = await store.get(id, { type: "json" });
    if (!quote) return notFound();
    await Promise.all(quote.photos.map(ph => photoStore.delete(`${id}/${ph.id}`)));
    await store.delete(id);
    return json(200, { ok: true });
}

function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// ---------- Authentication ----------

async function login(req, context, store, env) {
    const expected = env.ADMIN_PASSWORD;
    if (!expected || expected.length < MIN_PASSWORD_LENGTH) {
        console.error(`ADMIN_PASSWORD is not set or is shorter than ${MIN_PASSWORD_LENGTH} characters`);
        return json(503, { error: "Área administrativa não configurada." });
    }

    const ip = context?.ip || req.headers.get("x-nf-client-connection-ip") || "unknown";
    const attemptsKey = "login-attempts/" + sha256(ip);
    const now = Date.now();
    let attempts = await store.get(attemptsKey, { type: "json" });
    if (attempts?.lockedUntil > now) {
        return json(429, { error: "Demasiadas tentativas. Tente novamente dentro de 15 minutos." });
    }
    if (!attempts || now - attempts.first > LOCKOUT_MS) attempts = { count: 0, first: now, lockedUntil: 0 };

    let password = "";
    try {
        const body = await req.json();
        if (typeof body?.password === "string") password = body.password;
    } catch {
        // Invalid body is treated as a wrong password
    }

    if (!password || !safeEqual(password, expected)) {
        attempts.count += 1;
        if (attempts.count >= MAX_FAILED_LOGINS) attempts.lockedUntil = now + LOCKOUT_MS;
        await store.setJSON(attemptsKey, attempts);
        return json(401, { error: "Palavra-passe incorreta. Tente novamente." });
    }

    await store.delete(attemptsKey);
    const token = randomBytes(32).toString("hex");
    // Only the token's hash is stored, so the store itself never holds a usable session
    await store.setJSON("sessions/" + sha256(token), { expires: now + SESSION_TTL_MS });
    return json(200, { ok: true }, {
        "Set-Cookie": `${COOKIE}=${token}; ${COOKIE_ATTRS}; Max-Age=${SESSION_TTL_MS / 1000}`,
    });
}

async function logout(req, store) {
    const token = readCookie(req, COOKIE);
    if (token && TOKEN_PATTERN.test(token)) await store.delete("sessions/" + sha256(token));
    return json(200, { ok: true }, { "Set-Cookie": `${COOKIE}=; ${COOKIE_ATTRS}; Max-Age=0` });
}

async function getSession(req, store) {
    const token = readCookie(req, COOKIE);
    if (!token || !TOKEN_PATTERN.test(token)) return null;
    const key = "sessions/" + sha256(token);
    const session = await store.get(key, { type: "json" });
    if (!session) return null;
    if (session.expires < Date.now()) {
        await store.delete(key);
        return null;
    }
    return session;
}

// ---------- Helpers ----------

function isSameOrigin(req, url) {
    // Browsers set Sec-Fetch-Site themselves and scripts cannot forge it
    const site = req.headers.get("sec-fetch-site");
    if (site) return site === "same-origin";
    const origin = req.headers.get("origin");
    if (!origin) return false;
    try {
        return new URL(origin).host === url.host;
    } catch {
        return false;
    }
}

function readCookie(req, name) {
    for (const part of (req.headers.get("cookie") || "").split(";")) {
        const [key, ...value] = part.trim().split("=");
        if (key === name) return value.join("=");
    }
    return null;
}

function sha256(value) {
    return createHash("sha256").update(value).digest("hex");
}

function safeEqual(a, b) {
    return timingSafeEqual(createHash("sha256").update(a).digest(), createHash("sha256").update(b).digest());
}

function json(status, body, headers = {}) {
    return new Response(JSON.stringify(body), {
        status,
        headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...headers },
    });
}
